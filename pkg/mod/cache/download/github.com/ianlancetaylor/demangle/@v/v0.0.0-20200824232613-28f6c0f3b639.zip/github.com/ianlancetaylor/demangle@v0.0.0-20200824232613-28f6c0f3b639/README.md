# github.com/ianlancetaylor/demangle

A Go package that can be used to demangle C++ symbol names.
