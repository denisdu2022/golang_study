// Package isolation provides implementation of concurrency limiting (semaphore isolation).
package isolation
