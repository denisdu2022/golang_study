// Package config provides general configuration mechanism.
package config
