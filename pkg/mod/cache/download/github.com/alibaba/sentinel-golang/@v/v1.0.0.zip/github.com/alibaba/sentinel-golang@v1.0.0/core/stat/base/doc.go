// Package stat/base provides fundamental data structures of statistics.
package base
