// Package ext/datasource provides interfaces and helper classes of dynamic data-source.
package datasource
