// Package hotspot provides implementation of "hot-spot" (frequent) parameter flow control.
package hotspot
