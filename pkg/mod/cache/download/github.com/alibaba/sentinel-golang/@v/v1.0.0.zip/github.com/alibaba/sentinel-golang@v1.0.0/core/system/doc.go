// Package system provides implementation of adaptive system protection.
package system
