# Serf Client

This repo provide the `client` package, which is used to interact with
a Serf agent using the msgpack RPC system it supports. This is the official
reference implementation, and is used inside the Serf CLI to support the various
commands.

Full documentation can be found on [godoc here](https://godoc.org/github.com/hashicorp/serf/client).
