Test for [Issue#4](https://github.com/golang/mock/issues/4).
