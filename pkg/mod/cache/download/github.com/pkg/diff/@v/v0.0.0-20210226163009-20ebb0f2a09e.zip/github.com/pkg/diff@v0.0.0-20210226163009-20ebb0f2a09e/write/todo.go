package write

// TODO: add diff writing that uses < and > (don't know what that is called)
// TODO: add side by side diffs
// TODO: add html diffs (?)
// TODO: add intraline highlighting?
// TODO: a way to specify alternative colors, like a ColorScheme write option
