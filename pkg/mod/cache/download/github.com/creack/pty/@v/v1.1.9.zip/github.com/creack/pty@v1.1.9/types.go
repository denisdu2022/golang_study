// +build ignore

package pty

import "C"

type (
	_C_int  C.int
	_C_uint C.uint
)
