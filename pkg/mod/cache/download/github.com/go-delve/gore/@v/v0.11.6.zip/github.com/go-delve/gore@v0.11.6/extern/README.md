# Code copied from other Go modules

This package holds code copied and modified from other
open source projects. Each file is licensed under its
original license.