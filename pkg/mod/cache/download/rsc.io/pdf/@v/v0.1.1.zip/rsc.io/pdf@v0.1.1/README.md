go get rsc.io/pdf

http://godoc.org/rsc.io/pdf
